from django.shortcuts import render
from django.core.files.storage import *
import os
from fakelogo import settings
from . import image_pridiction
# Create your views here.
def index(request):
    return render(request,"index.html",context={'upload_img':1})

def upload_img(request):
    if request.method=="POST":
        os.remove(os.path.join(settings.MEDIA_ROOT, "imagetotest.jpg"))
        result=request.FILES
        file=result['LI']
        fs=FileSystemStorage()
        fs.save("imagetotest.jpg",file)
    data=image_pridiction.pridict_img()
    if data!=None:
        filename=data['filename'].split('.')[0]
        logo_name=filename[:-1]
    print()
    return render(request,"index.html",context={'upload_img':2,'pridication':2,'logo_name':logo_name})

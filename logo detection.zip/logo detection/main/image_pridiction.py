import cv2
from skimage.metrics import structural_similarity as ssim
from skimage.color import rgb2gray
import os
import numpy as np
from fakelogo import settings
# Load the reference image
#reference_image = cv2.imread('/static/imagetotest.jpg')


# Function to exclude white regions from an image
def exclude_white_regions(image):
    # Convert the image to grayscale
    gray_image = rgb2gray(image)

    # Create a binary mask for non-white regions
    mask = gray_image < 0.9  # Adjust the threshold as needed

    # Apply the mask to the original image
    non_white_image = image.copy()
    non_white_image[~mask] = [0, 0, 0]

    return non_white_image


# Iterate through the target images in the directory
def pridict_img():
    reference_image = cv2.imread(os.path.join(settings.BASE_DIR,  '/logo detection/static/imagetotest.jpg'))
    target_images_dir = os.path.join(settings.BASE_DIR,  '/logo detection/main/learningimg/')

    similarity_threshold = 0.65

    best_similarity = 0

    win_size = 3  # Adjust as needed based on your image sizes

    for filename in os.listdir(target_images_dir):
        if filename.endswith('.jpg') or filename.endswith('.png'):
            target_image = cv2.imread(os.path.join(target_images_dir, filename))
            target_image = cv2.resize(target_image, (reference_image.shape[1], reference_image.shape[0]))
            # Exclude white regions from the images
            reference_image_non_white = exclude_white_regions(reference_image)
            target_image_non_white = exclude_white_regions(target_image)

            # Compute the SSIM between the non-white regions of the reference image and the target image
            similarity = ssim(reference_image_non_white, target_image_non_white, multichannel=True, win_size=win_size,
                            data_range=255)
            print(filename,similarity)
            # Check if the similarity is above the threshold
            if similarity > similarity_threshold:
                print(f'Similarity with {filename}: {similarity}')

                # Update the most similar image if needed
                if similarity > best_similarity:
                    most_similar_image = target_image
                    best_similarity = similarity
                return {'similarity':similarity,'filename':filename}
